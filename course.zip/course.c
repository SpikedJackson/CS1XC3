/**
* @file course.c
* @author Jackson Timewell
* @version 1.0
* @brief This file defines all functions needed for courses 
* @date 2022-04-09
*/
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
* Enrolls a student in a course
* 
* @param course the course that the student is enrolled in
* @param student the student that will be in enrolled
* @return nothing
*/
void enroll_student(Course *course, Student *student)
{
  //Increase the courses number of students, using calloc for first student and realloc for additional students
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
* Prints a courses name, code, and students
* 
* @param course the course who's info is printed
* @return nothing
*/
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
* Finds the top student in a course
* 
* @param course the course to find top student in
* @return a pointer to the top student
*/
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  //Using a loop, find maximum average of the students
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
* Finds all students passing a course
* 
* @param course the course to find all students passing in
* @param total_passing a pointer to the int for number of students passing the course
* @return a pointer to the array of students passing the course
*/
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  //Using a loop, count number of passing students
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  //Create a dynamically allocated array for the number of passing students
  passing = calloc(count, sizeof(Student));
  //Using a loop, add passing students to array
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}