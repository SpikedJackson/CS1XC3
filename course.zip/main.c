/**
* @file main.c
* @author Jackson Timewell
* @version 1.0
* @brief This file is the start of the code and references other files to complete 
* @date 2022-04-09
*/
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"
/**
* Using a random seed, the main function will create a course, fill it with students, and print the course, top student, and passing students.
* 
* @param nothing
* @return nothing
*/
int main()
{
  //Make use of computer's clock to generate random seed
  srand((unsigned) time(NULL));
  //Create course, assign it a name, code, and students, then print
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));

  print_course(MATH101);
  //Print top student of created course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);
  //Print all students passing the created course
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}