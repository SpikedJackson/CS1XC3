/**
* @file student.h
* @author Jackson Timewell
* @version 1.0
* @brief This file is the header for student.c, it creates the struct and functions needed for students 
* @date 2022-04-09
*/ 
/**
* Student type stores a student with fields first_name, last_name, id, grades, num_grades
*/ 
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name (maximum 49 char) */
  char last_name[50]; /**< the student's last name (maximum 49 char) */
  char id[11];  /**< the student's id */
  double *grades;  /**< a pointer to the student's grades */
  int num_grades;  /**< the number of grades a student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
